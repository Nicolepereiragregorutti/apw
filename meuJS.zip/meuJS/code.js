
function imprime(){
 let lg = document.getElementById("login").value 
 let ps=document.getElementById("pass").value

let senha = "cacau"

if(ps==senha){
    alert("voce está logade")
} else (
    alert("tente novamente")
)


}